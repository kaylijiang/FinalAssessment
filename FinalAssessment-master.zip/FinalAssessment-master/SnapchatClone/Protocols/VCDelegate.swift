//
//  File.swift
//  SnapchatClone
//
//  Created by Max Miranda on 10/24/18.
//  Copyright © 2018 ___MaxAMiranda___. All rights reserved.
//

protocol VCDelegate {
    /* PART 3A START*/
    
    /* PART 3A FINISH*/
}
